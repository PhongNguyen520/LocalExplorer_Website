import React, { useEffect } from "react";

export function Sheet({ open, onOpenChange, children }) {
 useEffect(() => {
    if (!open) return;
    const handleEsc = (e) => {
      if (e.key === "Escape") onOpenChange(false);
    };
    window.addEventListener("keydown", handleEsc);
    return () => window.removeEventListener("keydown", handleEsc);
  }, [open, onOpenChange]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="fixed inset-0 bg-black/30" onClick={() => onOpenChange(false)} />
      {children}
    </div>
  );
}

export function SheetContent({ children, side = "right", className = "" }) {
  const sideClass =
    side === "right"
      ? "fixed right-0 top-0 h-full bg-white shadow-lg animate-in slide-in-from-right w-[400px]"
      : "";
  return (
    <div className={`${sideClass} ${className} z-50`}>{children}</div>
  );
}

export function SheetHeader({ children }) {
  return <div className="mb-4">{children}</div>;
}
export function SheetTitle({ children }) {
  return <h2 className="text-xl font-bold mb-1">{children}</h2>;
}
export function SheetDescription({ children }) {
  return <p className="text-slate-500 text-sm">{children}</p>;
} 