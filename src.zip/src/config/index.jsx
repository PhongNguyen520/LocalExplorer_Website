import routes from "./routes";

const config = {
    routes
}

export default config;