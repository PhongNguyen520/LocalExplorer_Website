"use client"

import { useState } from "react"
import {
  Download,
  Filter,
  Plus,
  Search,
  MoreHorizontal,
  MapPin,
  Star,
  Calendar,
  Eye,
  Edit,
  Trash2,
  Building2,
  TrendingUp,
  Users,
  DollarSign,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/Admin/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/Admin/ui/table"
import { Button } from "../../components/Admin/ui/button"
import { Input } from "../../components/Admin/ui/input"
import { Badge } from "../../components/Admin/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "../../components/Admin/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/Admin/ui/select"
import CountUp from "react-countup"

const businesses = [
  {
    id: 1,
    name: "Hanoi Food Tour",
    introduction: "Khám phá ẩm thực đường phố Hà Nội",
    description: "Tour ẩm thực độc đáo với hướng dẫn viên địa phương",
    logo: "/placeholder.svg?height=40&width=40",
    background: "/placeholder.svg?height=200&width=300",
    website: "https://hanoifoodtour.com",
    openTime: "08:00",
    closeTime: "22:00",
    avgRating: 4.8,
    totalFeedback: 124,
    status: "Active",
    cost: 250000,
    favoriteCount: 89,
    location: {
      provinceName: "Hà Nội",
      districtName: "Hoàn Kiếm",
      addressDetail: "36 Hàng Đào",
    },
    pricingPlan: "Premium",
    expiredTime: "2024-12-31",
    createdTime: "2024-01-15T10:30:00Z",
    lastUpdatedTime: "2024-03-10T14:20:00Z",
  },
  {
    id: 2,
    name: "Saigon City Tour",
    introduction: "Khám phá Sài Gòn hiện đại và lịch sử",
    description: "Tour tham quan các địa điểm nổi tiếng TP.HCM",
    logo: "/placeholder.svg?height=40&width=40",
    background: "/placeholder.svg?height=200&width=300",
    website: "https://saigoncitytour.com",
    openTime: "07:00",
    closeTime: "19:00",
    avgRating: 4.6,
    totalFeedback: 98,
    status: "Active",
    cost: 300000,
    favoriteCount: 67,
    location: {
      provinceName: "TP. Hồ Chí Minh",
      districtName: "Quận 1",
      addressDetail: "23 Lê Lợi",
    },
    pricingPlan: "Standard",
    expiredTime: "2024-11-30",
    createdTime: "2024-02-01T09:15:00Z",
    lastUpdatedTime: "2024-03-12T16:45:00Z",
  },
  {
    id: 3,
    name: "Hue Imperial City Tour",
    introduction: "Khám phá cố đô Huế",
    description: "Tour tham quan hoàng cung và lăng tẩm",
    logo: "/placeholder.svg?height=40&width=40",
    background: "/placeholder.svg?height=200&width=300",
    website: "https://hueimperialtour.com",
    openTime: "06:00",
    closeTime: "18:00",
    avgRating: 4.7,
    totalFeedback: 76,
    status: "Pending",
    cost: 200000,
    favoriteCount: 45,
    location: {
      provinceName: "Thừa Thiên Huế",
      districtName: "TP. Huế",
      addressDetail: "10 Trần Hưng Đạo",
    },
    pricingPlan: "Basic",
    expiredTime: "2024-10-15",
    createdTime: "2024-01-20T11:00:00Z",
    lastUpdatedTime: "2024-02-28T13:30:00Z",
  },
]

export default function BusinessesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterPlan, setFilterPlan] = useState("all")

  const filteredBusinesses = businesses.filter((business) => {
    const matchesSearch =
      business.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      business.introduction.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === "all" || business.status.toLowerCase() === filterStatus.toLowerCase()
    const matchesPlan = filterPlan === "all" || business.pricingPlan.toLowerCase() === filterPlan.toLowerCase()
    return matchesSearch && matchesStatus && matchesPlan
  })

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "suspended":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPlanColor = (plan) => {
    switch (plan.toLowerCase()) {
      case "premium":
        return "bg-purple-100 text-purple-800"
      case "standard":
        return "bg-blue-100 text-blue-800"
      case "basic":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Quản lý doanh nghiệp</h1>
          <p className="text-slate-600 mt-1">Quản lý tất cả doanh nghiệp đối tác trong hệ thống</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" className="border-slate-200 hover:bg-slate-50">
            <Download className="w-4 h-4 mr-2" />
            Xuất dữ liệu
          </Button>
          <Button className="bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-600 hover:to-emerald-700">
            <Plus className="w-4 h-4 mr-2" />
            Thêm doanh nghiệp
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-0 shadow-lg bg-gradient-to-br from-emerald-50 to-emerald-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-emerald-600 text-sm font-medium">Tổng doanh nghiệp</p>
                <p className="text-3xl font-bold text-emerald-900"><CountUp end={1234} duration={1.2} separator="," /></p>
                <p className="text-emerald-600 text-xs mt-1">+8.2% từ tháng trước</p>
              </div>
              <div className="w-12 h-12 bg-emerald-500 rounded-xl flex items-center justify-center">
                <Building2 className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 text-sm font-medium">Đang hoạt động</p>
                <p className="text-3xl font-bold text-blue-900"><CountUp end={1156} duration={1.2} separator="," /></p>
                <p className="text-blue-600 text-xs mt-1">+5.1% từ tháng trước</p>
              </div>
              <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-yellow-50 to-yellow-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-600 text-sm font-medium">Chờ duyệt</p>
                <p className="text-3xl font-bold text-yellow-900"><CountUp end={45} duration={1.2} separator="," /></p>
                <p className="text-yellow-600 text-xs mt-1">+12 đơn mới</p>
              </div>
              <div className="w-12 h-12 bg-yellow-500 rounded-xl flex items-center justify-center">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 text-sm font-medium">Doanh thu tháng</p>
                <p className="text-3xl font-bold text-purple-900">₫<CountUp end={89400000} duration={1.2} separator="," /></p>
                <p className="text-purple-600 text-xs mt-1">+15.3% từ tháng trước</p>
              </div>
              <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Search */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  type="search"
                  placeholder="Tìm kiếm doanh nghiệp..."
                  className="w-80 pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Lọc theo trạng thái" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả trạng thái</SelectItem>
                  <SelectItem value="active">Hoạt động</SelectItem>
                  <SelectItem value="pending">Chờ duyệt</SelectItem>
                  <SelectItem value="suspended">Tạm ngưng</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterPlan} onValueChange={setFilterPlan}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Lọc theo gói" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả gói</SelectItem>
                  <SelectItem value="premium">Premium</SelectItem>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="basic">Basic</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Bộ lọc nâng cao
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Businesses Table */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Danh sách doanh nghiệp</CardTitle>
          <CardDescription>
            Hiển thị {filteredBusinesses.length} trong tổng số {businesses.length} doanh nghiệp
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <input type="checkbox" className="rounded" />
                  </TableHead>
                  <TableHead>Doanh nghiệp</TableHead>
                  <TableHead>Địa điểm</TableHead>
                  <TableHead>Đánh giá</TableHead>
                  <TableHead>Gói dịch vụ</TableHead>
                  <TableHead>Doanh thu</TableHead>
                  <TableHead>Trạng thái</TableHead>
                  <TableHead className="text-right">Hành động</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBusinesses.map((business) => (
                  <TableRow key={business.id} className="hover:bg-slate-50">
                    <TableCell>
                      <input type="checkbox" className="rounded" />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12 rounded-lg">
                          <AvatarImage src={business.logo || "/placeholder.svg"} alt={business.name} />
                          <AvatarFallback className="bg-gradient-to-r from-emerald-500 to-blue-500 text-white rounded-lg">
                            {business.name.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-slate-900">{business.name}</p>
                          <p className="text-sm text-slate-500">{business.introduction}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            <span className="text-xs text-slate-500">
                              {business.openTime} - {business.closeTime}
                            </span>
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-start gap-2">
                        <MapPin className="w-4 h-4 text-slate-400 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium">{business.location.provinceName}</p>
                          <p className="text-xs text-slate-500">{business.location.districtName}</p>
                          <p className="text-xs text-slate-500">{business.location.addressDetail}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="font-medium">{business.avgRating}</span>
                        </div>
                        <span className="text-sm text-slate-500">({business.totalFeedback})</span>
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{business.favoriteCount} yêu thích</p>
                    </TableCell>
                    <TableCell>
                      <Badge className={getPlanColor(business.pricingPlan)}>{business.pricingPlan}</Badge>
                      <p className="text-xs text-slate-500 mt-1">
                        Hết hạn: {new Date(business.expiredTime).toLocaleDateString("vi-VN")}
                      </p>
                    </TableCell>
                    <TableCell>
                      <p className="font-medium">₫{business.cost.toLocaleString()}</p>
                      <p className="text-xs text-slate-500">Trung bình/tour</p>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(business.status)}>
                        {business.status === "Active"
                          ? "Hoạt động"
                          : business.status === "Pending"
                            ? "Chờ duyệt"
                            : "Tạm ngưng"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm" title="Xem chi tiết">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" title="Chỉnh sửa">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm" title="Xóa">
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-between space-x-2 py-4">
            <div className="text-sm text-slate-500">
              Hiển thị {filteredBusinesses.length} trong tổng số {businesses.length} doanh nghiệp
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                Trước
              </Button>
              <Button variant="outline" size="sm">
                Sau
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
