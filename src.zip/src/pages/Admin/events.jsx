"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/Admin/ui/card"
import { Button } from "../../components/Admin/ui/button"
import { Input } from "../../components/Admin/ui/input"
import { Badge } from "../../components/Admin/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/Admin/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/Admin/ui/select"
import { Textarea } from "../../components/Admin/ui/textarea"
import { Label } from "../../components/Admin/ui/label"
import { Calendar, MapPin, Users, Eye, Edit, Trash2, Plus, Search, Clock, Star, ImageIcon } from "lucide-react"

const EventsPage = () => {
  const [events, setEvents] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [showCreateModal, setShowCreateModal] = useState(false)

  // Mock data - replace with actual API calls
  const mockEvents = [
    {
      id: 1,
      name: "Festival Ẩm thực Sài Gòn 2024",
      description: "Lễ hội ẩm thực lớn nhất năm với hơn 100 gian hàng",
      startDate: "2024-02-15T09:00:00",
      endDate: "2024-02-18T22:00:00",
      image: "/placeholder.svg?height=100&width=150",
      status: "active",
      businessId: 123,
      businessName: "Công ty Tổ chức Sự kiện ABC",
      location: "Công viên Tao Đàn, Q1, TP.HCM",
      attendees: 2500,
      maxAttendees: 3000,
      price: 50000,
      createdTime: "2024-01-10T14:30:00",
    },
    {
      id: 2,
      name: "Hội thảo Khởi nghiệp 2024",
      description: "Chia sẻ kinh nghiệm khởi nghiệp từ các chuyên gia hàng đầu",
      startDate: "2024-02-20T08:30:00",
      endDate: "2024-02-20T17:00:00",
      image: "/placeholder.svg?height=100&width=150",
      status: "pending",
      businessId: 456,
      businessName: "Trung tâm Đào tạo XYZ",
      location: "Khách sạn Rex, Q1, TP.HCM",
      attendees: 150,
      maxAttendees: 200,
      price: 0,
      createdTime: "2024-01-12T10:15:00",
    },
    {
      id: 3,
      name: "Triển lãm Công nghệ 4.0",
      description: "Trưng bày các sản phẩm công nghệ mới nhất",
      startDate: "2024-01-25T10:00:00",
      endDate: "2024-01-27T18:00:00",
      image: "/placeholder.svg?height=100&width=150",
      status: "completed",
      businessId: 789,
      businessName: "Công ty Công nghệ DEF",
      location: "Trung tâm Hội nghị SECC, Q7, TP.HCM",
      attendees: 1200,
      maxAttendees: 1500,
      price: 100000,
      createdTime: "2024-01-05T16:45:00",
    },
  ]

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setEvents(mockEvents)
      setLoading(false)
    }, 1000)
  }, [])

  const getStatusBadge = (status) => {
    const statusConfig = {
      active: { label: "Đang diễn ra", color: "bg-green-100 text-green-800" },
      pending: { label: "Chờ duyệt", color: "bg-yellow-100 text-yellow-800" },
      completed: { label: "Đã kết thúc", color: "bg-gray-100 text-gray-800" },
      cancelled: { label: "Đã hủy", color: "bg-red-100 text-red-800" },
      upcoming: { label: "Sắp diễn ra", color: "bg-blue-100 text-blue-800" },
    }
    const config = statusConfig[status] || statusConfig.pending
    return <Badge className={config.color}>{config.label}</Badge>
  }

  const formatPrice = (price) => {
    if (price === 0) return "Miễn phí"
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(price)
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return {
      date: date.toLocaleDateString("vi-VN"),
      time: date.toLocaleTimeString("vi-VN", { hour: "2-digit", minute: "2-digit" }),
    }
  }

  const filteredEvents = events.filter((event) => {
    const matchesSearch =
      event.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      event.businessName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || event.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const stats = {
    total: events.length,
    active: events.filter((e) => e.status === "active").length,
    pending: events.filter((e) => e.status === "pending").length,
    completed: events.filter((e) => e.status === "completed").length,
    totalAttendees: events.reduce((sum, e) => sum + e.attendees, 0),
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Quản lý Sự kiện</h1>
          <p className="text-gray-600 mt-1">Quản lý và theo dõi các sự kiện trên hệ thống</p>
        </div>
        <Button onClick={() => setShowCreateModal(true)} className="bg-blue-600 hover:bg-blue-700">
          <Plus className="w-4 h-4 mr-2" />
          Tạo sự kiện
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Tổng sự kiện</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
              <Calendar className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Đang diễn ra</p>
                <p className="text-2xl font-bold text-green-600">{stats.active}</p>
              </div>
              <Clock className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Chờ duyệt</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
              </div>
              <Star className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Đã kết thúc</p>
                <p className="text-2xl font-bold text-gray-600">{stats.completed}</p>
              </div>
              <Calendar className="w-8 h-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Tổng người tham gia</p>
                <p className="text-2xl font-bold text-purple-600">{stats.totalAttendees.toLocaleString()}</p>
              </div>
              <Users className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Tìm kiếm sự kiện..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-48">
                <SelectValue placeholder="Trạng thái" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả trạng thái</SelectItem>
                <SelectItem value="active">Đang diễn ra</SelectItem>
                <SelectItem value="pending">Chờ duyệt</SelectItem>
                <SelectItem value="upcoming">Sắp diễn ra</SelectItem>
                <SelectItem value="completed">Đã kết thúc</SelectItem>
                <SelectItem value="cancelled">Đã hủy</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Events Table */}
      <Card>
        <CardHeader>
          <CardTitle>Danh sách Sự kiện</CardTitle>
          <CardDescription>
            Hiển thị {filteredEvents.length} trên tổng số {events.length} sự kiện
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Sự kiện</TableHead>
                <TableHead>Doanh nghiệp</TableHead>
                <TableHead>Thời gian</TableHead>
                <TableHead>Địa điểm</TableHead>
                <TableHead>Người tham gia</TableHead>
                <TableHead>Giá vé</TableHead>
                <TableHead>Trạng thái</TableHead>
                <TableHead>Hành động</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredEvents.map((event) => {
                const startDate = formatDate(event.startDate)
                const endDate = formatDate(event.endDate)
                return (
                  <TableRow key={event.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <ImageIcon
                          src={event.image || "/placeholder.svg"}
                          alt={event.name}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div>
                          <p className="font-medium text-gray-900">{event.name}</p>
                          <p className="text-sm text-gray-500 truncate max-w-xs">{event.description}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm font-medium">{event.businessName}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm font-medium">{startDate.date}</p>
                        <p className="text-xs text-gray-500">
                          {startDate.time} - {endDate.time}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 text-gray-400 mr-1" />
                        <p className="text-sm truncate max-w-xs">{event.location}</p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="text-sm font-medium">
                          {event.attendees.toLocaleString()} / {event.maxAttendees.toLocaleString()}
                        </p>
                        <div className="w-full bg-gray-200 rounded-full h-2 mt-1">
                          <div
                            className="bg-blue-600 h-2 rounded-full"
                            style={{ width: `${(event.attendees / event.maxAttendees) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="font-medium">
                        {formatPrice(event.price)}
                      </Badge>
                    </TableCell>
                    <TableCell>{getStatusBadge(event.status)}</TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Create Event Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Tạo sự kiện mới</CardTitle>
              <CardDescription>Tạo sự kiện mới cho doanh nghiệp</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Tên sự kiện</Label>
                    <Input id="name" placeholder="Nhập tên sự kiện" />
                  </div>
                  <div>
                    <Label htmlFor="description">Mô tả</Label>
                    <Textarea id="description" placeholder="Mô tả chi tiết về sự kiện" rows={3} />
                  </div>
                  <div>
                    <Label htmlFor="location">Địa điểm</Label>
                    <Input id="location" placeholder="Địa điểm tổ chức" />
                  </div>
                  <div>
                    <Label htmlFor="business">Doanh nghiệp</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Chọn doanh nghiệp" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="123">Công ty Tổ chức Sự kiện ABC</SelectItem>
                        <SelectItem value="456">Trung tâm Đào tạo XYZ</SelectItem>
                        <SelectItem value="789">Công ty Công nghệ DEF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="startDate">Ngày bắt đầu</Label>
                      <Input id="startDate" type="datetime-local" />
                    </div>
                    <div>
                      <Label htmlFor="endDate">Ngày kết thúc</Label>
                      <Input id="endDate" type="datetime-local" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="price">Giá vé (VND)</Label>
                      <Input id="price" type="number" placeholder="0" />
                    </div>
                    <div>
                      <Label htmlFor="maxAttendees">Số người tối đa</Label>
                      <Input id="maxAttendees" type="number" placeholder="100" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="image">Hình ảnh sự kiện</Label>
                    <Input id="image" type="file" accept="image/*" />
                  </div>
                  <div>
                    <Label htmlFor="status">Trạng thái</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Chọn trạng thái" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Chờ duyệt</SelectItem>
                        <SelectItem value="active">Kích hoạt</SelectItem>
                        <SelectItem value="upcoming">Sắp diễn ra</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setShowCreateModal(false)}>
                  Hủy
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-700">Tạo sự kiện</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

export default EventsPage
