import { MapPin, Plus, Search } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../../components/Admin/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/Admin/ui/table";
import { Button } from "../../components/Admin/ui/button";
import { Input } from "../../components/Admin/ui/input";

const locations = [
  {
    id: 1,
    district: "Hoan Kiem",
    province: "Hanoi",
    country: "Vietnam",
    addressDetail: "36 Hang Dao Street",
    businesses: 24,
  },
  {
    id: 2,
    district: "District 1",
    province: "Ho Chi Minh City",
    country: "Vietnam",
    addressDetail: "23 Le Loi Boulevard",
    businesses: 32,
  },
  {
    id: 3,
    district: "Hue City",
    province: "Thua Thien Hue",
    country: "Vietnam",
    addressDetail: "10 Tran Hung Dao Street",
    businesses: 18,
  },
  {
    id: 4,
    district: "Hoi An Ancient Town",
    province: "Quang Nam",
    country: "Vietnam",
    addressDetail: "15 Tran Phu Street",
    businesses: 27,
  },
  {
    id: 5,
    district: "Son Tra",
    province: "Da Nang",
    country: "Vietnam",
    addressDetail: "42 Bach Dang Street",
    businesses: 15,
  },
  {
    id: 6,
    district: "Ninh Kieu",
    province: "Can Tho",
    country: "Vietnam",
    addressDetail: "5 Hai Ba Trung Street",
    businesses: 12,
  },
  {
    id: 7,
    district: "Sapa Town",
    province: "Lao Cai",
    country: "Vietnam",
    addressDetail: "8 Fansipan Road",
    businesses: 9,
  },
];

export default function LocationsPage() {
  return (
    <>
      <div>
        <Card>
          <div className="flex items-center justify-between">
            <CardHeader>
              <CardTitle>Manage Locations</CardTitle>
            </CardHeader>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Location
            </Button>
          </div>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <div className="relative w-full max-w-sm">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search locations..."
                  className="w-full pl-8"
                />
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm">
                  <MapPin className="mr-2 h-4 w-4" />
                  Map View
                </Button>
                <Button variant="outline" size="sm">
                  Filter
                </Button>
              </div>
            </div>
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>District</TableHead>
                    <TableHead>Province</TableHead>
                    <TableHead>Country</TableHead>
                    <TableHead>Address</TableHead>
                    <TableHead>Businesses</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {locations.map((location) => (
                    <TableRow key={location.id}>
                      <TableCell className="font-medium">
                        {location.district}
                      </TableCell>
                      <TableCell>{location.province}</TableCell>
                      <TableCell>{location.country}</TableCell>
                      <TableCell>{location.addressDetail}</TableCell>
                      <TableCell>{location.businesses}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <div className="flex items-center justify-end space-x-2 py-4">
              <Button variant="outline" size="sm">
                Previous
              </Button>
              <Button variant="outline" size="sm">
                Next
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </>
  );
}
