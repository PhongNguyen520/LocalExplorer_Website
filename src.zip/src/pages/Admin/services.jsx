"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/Admin/ui/card"
import { Button } from "../../components/Admin/ui/button"
import { Input } from "../../components/Admin/ui/input"
import { Badge } from "../../components/Admin/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/Admin/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/Admin/ui/select"
import { Textarea } from "../../components/Admin/ui/textarea"
import { Label } from "../../components/Admin/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/Admin/ui/tabs"
import {
  Plus,
  Search,
  Eye,
  Edit,
  Trash2,
  Star,
  Clock,
  DollarSign,
  Package,
  Tag,
  CheckCircle,
  XCircle,
} from "lucide-react"

const ServicesPage = () => {
  const [services, setServices] = useState([])
  const [serviceTypes, setServiceTypes] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showCreateTypeModal, setShowCreateTypeModal] = useState(false)

  // Mock data - replace with actual API calls
  const mockServices = [
    {
      id: 1,
      name: "Massage thư giãn toàn thân",
      description: "Dịch vụ massage chuyên nghiệp giúp thư giãn và giảm stress",
      price: 500000,
      discount: 10,
      availability: true,
      duration: 90,
      inclusions: ["Tinh dầu thảo dược", "Khăn nóng", "Trà thảo mộc"],
      exclusions: ["Không bao gồm tip"],
      condition: "Khách hàng cần đặt trước 24h",
      status: "active",
      businessId: 123,
      businessName: "Spa ABC",
      serviceTypeId: 1,
      serviceTypeName: "Spa & Wellness",
      rating: 4.8,
      bookingCount: 156,
      createdTime: "2024-01-10T10:30:00",
    },
    {
      id: 2,
      name: "Tour du lịch Đà Lạt 3N2Đ",
      description: "Tour trọn gói khám phá thành phố ngàn hoa",
      price: 2500000,
      discount: 15,
      availability: true,
      duration: 4320, // 3 days in minutes
      inclusions: ["Khách sạn 4 sao", "Xe đưa đón", "Bữa ăn", "Hướng dẫn viên"],
      exclusions: ["Vé máy bay", "Chi phí cá nhân"],
      condition: "Tối thiểu 4 người",
      status: "active",
      businessId: 456,
      businessName: "Du lịch XYZ",
      serviceTypeId: 2,
      serviceTypeName: "Du lịch",
      rating: 4.6,
      bookingCount: 89,
      createdTime: "2024-01-08T14:20:00",
    },
    {
      id: 3,
      name: "Khóa học Yoga cơ bản",
      description: "Khóa học Yoga 8 buổi cho người mới bắt đầu",
      price: 800000,
      discount: 0,
      availability: false,
      duration: 60,
      inclusions: ["Thảm yoga", "Nước uống", "Tài liệu hướng dẫn"],
      exclusions: ["Trang phục yoga"],
      condition: "Lớp tối đa 15 người",
      status: "inactive",
      businessId: 789,
      businessName: "Yoga Center DEF",
      serviceTypeId: 3,
      serviceTypeName: "Thể thao & Sức khỏe",
      rating: 4.9,
      bookingCount: 234,
      createdTime: "2024-01-05T09:15:00",
    },
  ]

  const mockServiceTypes = [
    {
      id: 1,
      name: "Spa & Wellness",
      icon: "🧘",
      description: "Dịch vụ chăm sóc sức khỏe và làm đẹp",
      status: "active",
      serviceCount: 45,
      createdTime: "2024-01-01T00:00:00",
    },
    {
      id: 2,
      name: "Du lịch",
      icon: "✈️",
      description: "Dịch vụ du lịch và nghỉ dưỡng",
      status: "active",
      serviceCount: 32,
      createdTime: "2024-01-01T00:00:00",
    },
    {
      id: 3,
      name: "Thể thao & Sức khỏe",
      icon: "💪",
      description: "Dịch vụ thể thao và chăm sóc sức khỏe",
      status: "active",
      serviceCount: 28,
      createdTime: "2024-01-01T00:00:00",
    },
  ]

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setServices(mockServices)
      setServiceTypes(mockServiceTypes)
      setLoading(false)
    }, 1000)
  }, [])

  const getStatusBadge = (status) => {
    const statusConfig = {
      active: { label: "Hoạt động", color: "bg-green-100 text-green-800", icon: CheckCircle },
      inactive: { label: "Tạm dừng", color: "bg-red-100 text-red-800", icon: XCircle },
      pending: { label: "Chờ duyệt", color: "bg-yellow-100 text-yellow-800", icon: Clock },
    }
    const config = statusConfig[status] || statusConfig.pending
    const Icon = config.icon
    return (
      <Badge className={config.color}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    )
  }

  const formatPrice = (price) => {
    return new Intl.NumberFormat("vi-VN", {
      style: "currency",
      currency: "VND",
    }).format(price)
  }

  const formatDuration = (minutes) => {
    if (minutes >= 1440) {
      const days = Math.floor(minutes / 1440)
      return `${days} ngày`
    } else if (minutes >= 60) {
      const hours = Math.floor(minutes / 60)
      return `${hours} giờ`
    } else {
      return `${minutes} phút`
    }
  }

  const filteredServices = services.filter((service) => {
    const matchesSearch =
      service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.businessName.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || service.status === statusFilter
    const matchesType = typeFilter === "all" || service.serviceTypeId.toString() === typeFilter
    return matchesSearch && matchesStatus && matchesType
  })

  const stats = {
    totalServices: services.length,
    activeServices: services.filter((s) => s.status === "active").length,
    inactiveServices: services.filter((s) => s.status === "inactive").length,
    totalBookings: services.reduce((sum, s) => sum + s.bookingCount, 0),
    avgRating: services.reduce((sum, s) => sum + s.rating, 0) / services.length || 0,
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-end items-center">
        <div className="flex space-x-2">
          <Button onClick={() => setShowCreateTypeModal(true)} variant="outline">
            <Tag className="w-4 h-4 mr-2" />
            Tạo loại dịch vụ
          </Button>
          <Button onClick={() => setShowCreateModal(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Tạo dịch vụ
          </Button>
        </div>
      </div>

      <Tabs defaultValue="services" className="space-y-6">
        <TabsList>
          <TabsTrigger value="services">Dịch vụ</TabsTrigger>
          <TabsTrigger value="types">Loại dịch vụ</TabsTrigger>
        </TabsList>

        <TabsContent value="services" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Tổng dịch vụ</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalServices}</p>
                  </div>
                  <Package className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Đang hoạt động</p>
                    <p className="text-2xl font-bold text-green-600">{stats.activeServices}</p>
                  </div>
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Tạm dừng</p>
                    <p className="text-2xl font-bold text-red-600">{stats.inactiveServices}</p>
                  </div>
                  <XCircle className="w-8 h-8 text-red-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Tổng đặt chỗ</p>
                    <p className="text-2xl font-bold text-purple-600">{stats.totalBookings.toLocaleString()}</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Đánh giá TB</p>
                    <p className="text-2xl font-bold text-yellow-600">{stats.avgRating.toFixed(1)}</p>
                  </div>
                  <Star className="w-8 h-8 text-yellow-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Tìm kiếm dịch vụ..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Trạng thái" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tất cả trạng thái</SelectItem>
                    <SelectItem value="active">Hoạt động</SelectItem>
                    <SelectItem value="inactive">Tạm dừng</SelectItem>
                    <SelectItem value="pending">Chờ duyệt</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Loại dịch vụ" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Tất cả loại</SelectItem>
                    {serviceTypes.map((type) => (
                      <SelectItem key={type.id} value={type.id.toString()}>
                        {type.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Services Table */}
          <Card>
            <CardHeader>
              <CardTitle>Danh sách Dịch vụ</CardTitle>
              <CardDescription>
                Hiển thị {filteredServices.length} trên tổng số {services.length} dịch vụ
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Dịch vụ</TableHead>
                    <TableHead>Doanh nghiệp</TableHead>
                    <TableHead>Loại</TableHead>
                    <TableHead>Giá</TableHead>
                    <TableHead>Thời gian</TableHead>
                    <TableHead>Đánh giá</TableHead>
                    <TableHead>Đặt chỗ</TableHead>
                    <TableHead>Trạng thái</TableHead>
                    <TableHead>Hành động</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredServices.map((service) => (
                    <TableRow key={service.id}>
                      <TableCell>
                        <div>
                          <p className="font-medium text-gray-900">{service.name}</p>
                          <p className="text-sm text-gray-500 truncate max-w-xs">{service.description}</p>
                          {service.discount > 0 && (
                            <Badge variant="outline" className="mt-1 text-red-600">
                              -{service.discount}%
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="text-sm font-medium">{service.businessName}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{service.serviceTypeName}</Badge>
                      </TableCell>
                      <TableCell>
                        <div>
                          <p className="font-medium">{formatPrice(service.price)}</p>
                          {service.discount > 0 && (
                            <p className="text-xs text-gray-500 line-through">
                              {formatPrice(service.price / (1 - service.discount / 100))}
                            </p>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 text-gray-400 mr-1" />
                          <span className="text-sm">{formatDuration(service.duration)}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 text-yellow-400 mr-1" />
                          <span className="text-sm font-medium">{service.rating}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{service.bookingCount}</Badge>
                      </TableCell>
                      <TableCell>{getStatusBadge(service.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="types" className="space-y-6">
          {/* Service Types Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {serviceTypes.map((type) => (
              <Card key={type.id}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="text-2xl">{type.icon}</div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{type.name}</h3>
                        <p className="text-sm text-gray-500">{type.serviceCount} dịch vụ</p>
                      </div>
                    </div>
                    {getStatusBadge(type.status)}
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{type.description}</p>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Create Service Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
            <CardHeader>
              <CardTitle>Tạo dịch vụ mới</CardTitle>
              <CardDescription>Thêm dịch vụ mới vào hệ thống</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="name">Tên dịch vụ</Label>
                    <Input id="name" placeholder="Nhập tên dịch vụ" />
                  </div>
                  <div>
                    <Label htmlFor="description">Mô tả</Label>
                    <Textarea id="description" placeholder="Mô tả chi tiết về dịch vụ" rows={3} />
                  </div>
                  <div>
                    <Label htmlFor="serviceType">Loại dịch vụ</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Chọn loại dịch vụ" />
                      </SelectTrigger>
                      <SelectContent>
                        {serviceTypes.map((type) => (
                          <SelectItem key={type.id} value={type.id.toString()}>
                            {type.icon} {type.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="business">Doanh nghiệp</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Chọn doanh nghiệp" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="123">Spa ABC</SelectItem>
                        <SelectItem value="456">Du lịch XYZ</SelectItem>
                        <SelectItem value="789">Yoga Center DEF</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="price">Giá (VND)</Label>
                      <Input id="price" type="number" placeholder="0" />
                    </div>
                    <div>
                      <Label htmlFor="discount">Giảm giá (%)</Label>
                      <Input id="discount" type="number" placeholder="0" min="0" max="100" />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="duration">Thời gian (phút)</Label>
                    <Input id="duration" type="number" placeholder="60" />
                  </div>
                  <div>
                    <Label htmlFor="inclusions">Bao gồm</Label>
                    <Textarea id="inclusions" placeholder="Các dịch vụ bao gồm (mỗi dòng một mục)" rows={3} />
                  </div>
                  <div>
                    <Label htmlFor="exclusions">Không bao gồm</Label>
                    <Textarea id="exclusions" placeholder="Các dịch vụ không bao gồm (mỗi dòng một mục)" rows={2} />
                  </div>
                </div>
              </div>
              <div>
                <Label htmlFor="condition">Điều kiện</Label>
                <Textarea id="condition" placeholder="Điều kiện sử dụng dịch vụ" rows={2} />
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setShowCreateModal(false)}>
                  Hủy
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-700">Tạo dịch vụ</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Create Service Type Modal */}
      {showCreateTypeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <Card className="w-full max-w-2xl mx-4">
            <CardHeader>
              <CardTitle>Tạo loại dịch vụ mới</CardTitle>
              <CardDescription>Thêm loại dịch vụ mới vào hệ thống</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="typeName">Tên loại dịch vụ</Label>
                <Input id="typeName" placeholder="Nhập tên loại dịch vụ" />
              </div>
              <div>
                <Label htmlFor="typeIcon">Icon (Emoji)</Label>
                <Input id="typeIcon" placeholder="🎯" />
              </div>
              <div>
                <Label htmlFor="typeDescription">Mô tả</Label>
                <Textarea id="typeDescription" placeholder="Mô tả về loại dịch vụ này" rows={3} />
              </div>
              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setShowCreateTypeModal(false)}>
                  Hủy
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-700">Tạo loại dịch vụ</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

export default ServicesPage
