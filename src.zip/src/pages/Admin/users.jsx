"use client"

import { useState } from "react"
import {
  Download,
  Plus,
  Search,
  Filter,
  MoreHorizontal,
  Mail,
  Phone,
  Calendar,
  Shield,
  UserCheck,
  UserX,
  Eye,
  ChevronDown,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../../components/Admin/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../../components/Admin/ui/table"
import { Button } from "../../components/Admin/ui/button"
import { Input } from "../../components/Admin/ui/input"
import { Badge } from "../../components/Admin/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "../../components/Admin/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/Admin/ui/select"
import images from "../../assets/images"
import CountUp from "react-countup"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetDescription } from "../../components/Admin/ui/sheet"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "../../components/Admin/ui/dialog"

const users = [
  {
    id: 1,
    firstName: "Minh",
    lastName: "Nguyen",
    email: "minh.nguyen@example.com",
    phoneNumber: "0901234567",
    dob: "1990-05-15",
    gender: "Male",
    avatar: images.avatar,
    status: "Active",
    scheduleCount: 3,
    emailConfirmed: true,
    phoneNumberConfirmed: true,
    twoFactorEnabled: false,
    lockoutEnabled: false,
    accessFailedCount: 0,
    createdTime: "2024-01-15T10:30:00Z",
    lastUpdatedTime: "2024-03-10T14:20:00Z",
  },
  {
    id: 2,
    firstName: "Linh",
    lastName: "Tran",
    email: "linh.tran@example.com",
    phoneNumber: "0912345678",
    dob: "1992-08-22",
    gender: "Female",
    avatar: images.avatar,
    status: "Active",
    scheduleCount: 5,
    emailConfirmed: true,
    phoneNumberConfirmed: false,
    twoFactorEnabled: true,
    lockoutEnabled: false,
    accessFailedCount: 0,
    createdTime: "2024-02-01T09:15:00Z",
    lastUpdatedTime: "2024-03-12T16:45:00Z",
  },
  {
    id: 3,
    firstName: "Huy",
    lastName: "Pham",
    email: "huy.pham@example.com",
    phoneNumber: "0923456789",
    dob: "1988-12-03",
    gender: "Male",
    avatar: images.avatar,
    status: "Inactive",
    scheduleCount: 0,
    emailConfirmed: false,
    phoneNumberConfirmed: true,
    twoFactorEnabled: false,
    lockoutEnabled: true,
    accessFailedCount: 3,
    createdTime: "2024-01-20T11:00:00Z",
    lastUpdatedTime: "2024-02-28T13:30:00Z",
  },
  {
    id: 4,
    firstName: "Trang",
    lastName: "Le",
    email: "trang.le@example.com",
    phoneNumber: "0934567890",
    dob: "1995-03-18",
    gender: "Female",
    avatar: images.avatar,
    status: "Active",
    scheduleCount: 2,
    emailConfirmed: true,
    phoneNumberConfirmed: true,
    twoFactorEnabled: false,
    lockoutEnabled: false,
    accessFailedCount: 0,
    createdTime: "2024-02-10T15:20:00Z",
    lastUpdatedTime: "2024-03-08T10:15:00Z",
  },
]

export default function UsersPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [selectedUsers, setSelectedUsers] = useState([])
  const [openFilterSheet, setOpenFilterSheet] = useState(false)
  const [openUserModal, setOpenUserModal] = useState(false)
  const [modalUser, setModalUser] = useState(null)

  const filteredUsers = users.filter((user) => {
    const matchesSearch =
      user.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.email.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = filterStatus === "all" || user.status.toLowerCase() === filterStatus.toLowerCase()
    return matchesSearch && matchesStatus
  })

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "active":
        return "bg-green-100 text-green-800"
      case "inactive":
        return "bg-red-100 text-red-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const calculateAge = (dob) => {
    const today = new Date()
    const birthDate = new Date(dob)
    let age = today.getFullYear() - birthDate.getFullYear()
    const monthDiff = today.getMonth() - birthDate.getMonth()
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--
    }
    return age
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Quản lý người dùng</h1>
          <p className="text-slate-600 mt-1">Quản lý tất cả người dùng trong hệ thống</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="outline" className="border-slate-200 hover:bg-slate-50">
            <Download className="w-4 h-4 mr-2" />
            Xuất dữ liệu
          </Button>
          <Button className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700">
            <Plus className="w-4 h-4 mr-2" />
            Thêm người dùng
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-600 text-sm font-medium">Tổng người dùng</p>
                <p className="text-3xl font-bold text-blue-900"><CountUp end={52847} duration={1.2} separator="," /></p>
                <p className="text-blue-600 text-xs mt-1">+12.5% từ tháng trước</p>
              </div>
              <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-600 text-sm font-medium">Người dùng hoạt động</p>
                <p className="text-3xl font-bold text-green-900"><CountUp end={48291} duration={1.2} separator="," /></p>
                <p className="text-green-600 text-xs mt-1">+8.2% từ tháng trước</p>
              </div>
              <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-600 text-sm font-medium">Tài khoản chưa xác thực</p>
                <p className="text-3xl font-bold text-purple-900"><CountUp end={1234} duration={1.2} separator="," /></p>
                <p className="text-purple-600 text-xs mt-1">+15.3% từ tháng trước</p>
              </div>
              <div className="w-12 h-12 bg-purple-500 rounded-xl flex items-center justify-center">
                <Plus className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-lg bg-gradient-to-br from-red-50 to-red-100">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-600 text-sm font-medium">Tài khoản bị khóa</p>
                <p className="text-3xl font-bold text-red-900"><CountUp end={156} duration={1.2} separator="," /></p>
                <p className="text-red-600 text-xs mt-1">+2.1% từ tháng trước</p>
              </div>
              <div className="w-12 h-12 bg-red-500 rounded-xl flex items-center justify-center">
                <UserX className="w-6 h-6 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-10">
              <div className="relative">
                <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <Input
                  type="search"
                  placeholder="Tìm kiếm người dùng..."
                  className="w-80 pl-10"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-50 bg-white">
                  <SelectValue placeholder="Lọc theo trạng thái">Tất cả trạng thái</SelectValue>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active"><div className="w-2 h-2 bg-green-500 rounded-full"></div> Hoạt động</SelectItem>
                  <SelectItem value="inactive"><div className="w-2 h-2 bg-red-500 rounded-full"></div> Không hoạt động</SelectItem>
                  <SelectItem value="pending"><div className="w-2 h-2 bg-yellow-500 rounded-full"></div> Chờ xác thực</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={() => setOpenFilterSheet(true)}>
                <Filter className="w-4 h-4 mr-2" />
                Bộ lọc nâng cao
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card className="border-0 shadow-lg">
        <CardHeader>
          <CardTitle>Danh sách người dùng</CardTitle>
          <CardDescription>
            Hiển thị {filteredUsers.length} trong tổng số {users.length} người dùng
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Người dùng</TableHead>
                  <TableHead>Thông tin liên hệ</TableHead>
                  <TableHead>Thông tin cá nhân</TableHead>
                  <TableHead>Bảo mật</TableHead>
                  <TableHead>Hoạt động</TableHead>
                  <TableHead>Trạng thái</TableHead>
                  <TableHead className="text-right">Hành động</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id} className="hover:bg-slate-50">
                    {/* <TableCell>
                      <input type="checkbox" className="rounded" />
                    </TableCell> */}
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="w-10 h-10">
                          <AvatarImage
                            src={user.avatar || "/placeholder.svg"}
                            alt={`${user.firstName} ${user.lastName}`}
                          />
                          <AvatarFallback className="bg-gradient-to-r from-blue-500 to-purple-500 text-white">
                            {user.firstName.charAt(0)}
                            {user.lastName.charAt(0)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-slate-900">
                            {user.firstName} {user.lastName}
                          </p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Mail className="w-4 h-4 text-slate-400" />
                          <span className="text-sm">{user.email}</span>
                          {user.emailConfirmed && (
                            <Badge variant="outline" className="text-xs">
                              Đã xác thực
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-slate-400" />
                          <span className="text-sm">{user.phoneNumber}</span>
                          {/* {user.phoneNumberConfirmed && (
                            <Badge variant="outline" className="text-xs">
                              Đã xác thực
                            </Badge>
                          )} */}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-slate-400" />
                          <span className="text-sm">{calculateAge(user.dob)} tuổi, {user.gender === "Male" ? "Nam" : "Nữ"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm"></span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-slate-400" />
                          {user.twoFactorEnabled ? (
                            <Badge variant="default" className="text-xs">
                              2FA Bật
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-xs">
                              2FA Tắt
                            </Badge>
                          )}
                        </div>
                        {user.accessFailedCount > 0 && (
                          <Badge variant="destructive" className="text-xs">
                            {user.accessFailedCount} lần đăng nhập sai
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <p className="text-sm font-medium">{user.scheduleCount} lịch trình</p>
                        <p className="text-xs text-slate-500">
                          Cập nhật: {new Date(user.lastUpdatedTime).toLocaleDateString("vi-VN")}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(user.status)}>
                        {user.status === "Active" ? "Hoạt động" : "Không hoạt động"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Button variant="ghost" size="sm" onClick={() => { setModalUser(user); setOpenUserModal(true) }}>
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-between space-x-2 py-4">
            <div className="text-sm text-slate-500">
              Hiển thị {filteredUsers.length} trong tổng số {users.length} người dùng
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm">
                Trước
              </Button>
              <Button variant="outline" size="sm">
                Sau
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      <Sheet open={openFilterSheet} onOpenChange={setOpenFilterSheet}>
  <SheetContent
    side="right"
    className="w-full sm:max-w-sm md:max-w-md lg:w-[400px] p-0"
  >
    <div className="flex flex-col h-full">
      <SheetHeader className="p-4 sm:p-6 border-b">
        <SheetTitle className="text-lg sm:text-xl font-semibold">
          Bộ lọc nâng cao
        </SheetTitle>
        <SheetDescription className="text-sm text-muted-foreground">
          Lọc người dùng theo nhiều tiêu chí chi tiết hơn.
        </SheetDescription>
      </SheetHeader>

      <form className="flex-1 overflow-y-auto px-4 py-4 sm:px-6 sm:py-6 space-y-8">
        {/* Trạng thái tài khoản */}
        <div>
          <h3 className="text-base font-semibold text-slate-800 mb-3">
            Trạng thái tài khoản
          </h3>
          <div className="space-y-2">
            <label className="text-sm text-slate-600">Trạng thái</label>
            <Select>
              <SelectTrigger className="w-full rounded-md border border-slate-300 focus:ring-2 focus:ring-blue-500">
                <SelectValue placeholder="Chọn trạng thái" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tất cả</SelectItem>
                <SelectItem value="active">Hoạt động</SelectItem>
                <SelectItem value="inactive">Không hoạt động</SelectItem>
                <SelectItem value="pending">Chờ xác thực</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Xác thực */}
        <div>
          <h3 className="text-base font-semibold text-slate-800 mb-3">
            Xác thực
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-slate-600">Email</label>
              <Select>
                <SelectTrigger className="w-full rounded-md border border-slate-300 focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="Email" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  <SelectItem value="true">Đã xác thực</SelectItem>
                  <SelectItem value="false">Chưa xác thực</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-slate-600">Số điện thoại</label>
              <Select>
                <SelectTrigger className="w-full rounded-md border border-slate-300 focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="SĐT" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  <SelectItem value="true">Đã xác thực</SelectItem>
                  <SelectItem value="false">Chưa xác thực</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* Khác */}
        <div>
          <h3 className="text-base font-semibold text-slate-800 mb-3">Khác</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-slate-600">2FA</label>
              <Select>
                <SelectTrigger className="w-full rounded-md border border-slate-300 focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="2FA" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  <SelectItem value="true">Bật</SelectItem>
                  <SelectItem value="false">Tắt</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-slate-600">Giới tính</label>
              <Select>
                <SelectTrigger className="w-full rounded-md border border-slate-300 focus:ring-2 focus:ring-blue-500">
                  <SelectValue placeholder="Giới tính" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tất cả</SelectItem>
                  <SelectItem value="male">Nam</SelectItem>
                  <SelectItem value="female">Nữ</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </form>

      <div className="flex flex-col sm:flex-row gap-3 p-4 sm:p-6 border-t">
        <Button
          variant="outline"
          className="w-full sm:w-1/2 rounded-md text-sm"
        >
          Đặt lại
        </Button>
        <Button
          className="w-full sm:w-1/2 rounded-md text-sm bg-blue-600 hover:bg-blue-700 text-white"
        >
          Áp dụng lọc
        </Button>
      </div>
    </div>
  </SheetContent>
</Sheet>

      <Dialog open={openUserModal} onOpenChange={setOpenUserModal}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Thông tin người dùng</DialogTitle>
            <DialogDescription>Xem chi tiết và thao tác với người dùng.</DialogDescription>
          </DialogHeader>
          {modalUser && (
            <div className="space-y-4 mt-4">
              <div className="flex items-center gap-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={modalUser.avatar} alt={modalUser.firstName + ' ' + modalUser.lastName} />
                  <AvatarFallback>{modalUser.firstName.charAt(0)}{modalUser.lastName.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-bold text-lg">{modalUser.firstName} {modalUser.lastName}</div>
                  <div className="text-slate-500 text-sm">{modalUser.email}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div><b>Điện thoại:</b> {modalUser.phoneNumber}</div>
                <div><b>Giới tính:</b> {modalUser.gender === 'Male' ? 'Nam' : 'Nữ'}</div>
                <div><b>Ngày sinh:</b> {modalUser.dob}</div>
                <div><b>Trạng thái:</b> {modalUser.status}</div>
                <div><b>Lịch trình:</b> {modalUser.scheduleCount}</div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button variant="destructive">Khoá tài khoản</Button>
                <Button variant="outline">Xoá</Button>
                <Button variant="default">Xác thực Email</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
